import "./profile.scss"
//import location from "../../icons/location-pin-alt-1-svgrepo-com.svg"


const Profile = () => {
    return(
        <div className="profile">Profile</div>
    )
}

export default Profile