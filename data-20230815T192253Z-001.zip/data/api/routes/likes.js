import express from "express";
import { } from "../controllers/like.js";

const router = express.Router();


router.get("", );

export default router;