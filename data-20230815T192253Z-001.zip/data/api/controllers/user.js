export const getUser = (req,res)=>{
   
}